#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Descriptif du fichier
"""

# Importation des librairies
import no_ifname


# Programme principal
if __name__ == "__main__":
    print("Résultat de la fonction de la librairie {}".format(no_ifname.useful_function(3)))

