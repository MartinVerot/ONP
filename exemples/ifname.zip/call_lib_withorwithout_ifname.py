#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Descriptif du fichier
"""

# Importation des librairies
import no_ifname
import with_ifname

# Programme principal
if __name__ == "__main__":
    print("Résultat de la fonction de la librairie sans if __name__ == \"__main__\": {}".format(no_ifname.useful_function(3)))
    print("Résultat de la fonction de la librairie avec if __name__ == \"__main__\":{}".format(with_ifname.useful_function(3)))

