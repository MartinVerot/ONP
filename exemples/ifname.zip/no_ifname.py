#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Descriptif du fichier
"""

# Importation des librairies
import time
# Definition des fonctions
def useful_function(x):
    """
    Fonction d'une utilité cruciale que vous avez besoin d'importer
    """
    return x**2


# Programme principal
for i in range(10):
    time.sleep(1)
    print("Vous attendez depuis {} secondes".format(i+1))

