#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Descriptif du fichier
"""

# Importation des librairies

# Definition des fonctions

# Programme principal
if __name__ == "__main__":
   pass

